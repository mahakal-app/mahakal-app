MAHAKAL v4 — Online AI

1. Install Node.js 20+.
2. In this folder run:
   npm install
3. Set your OpenAI API key on the SERVER (never put it in index.html):
   Windows PowerShell:
     $env:OPENAI_API_KEY="YOUR_KEY"
   macOS/Linux:
     export OPENAI_API_KEY="YOUR_KEY"
4. Start:
     npm start
5. Open:
     http://localhost:3000

Demo login: admin / admin

The Online AI tab sends selected historical records to the server and uses the OpenAI Responses API.
The AI is restricted to historical descriptive analysis; it does not provide future winning/betting predictions.

For public hosting, use HTTPS, a real database, hashed admin passwords, rate limiting and server-side authentication.
