import express from "express";
import OpenAI from "openai";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const client = new OpenAI(); // reads OPENAI_API_KEY from environment

app.use(express.json({limit:"2mb"}));
app.use(express.static(__dirname));

app.post("/api/ai-analyze", async (req,res)=>{
  try {
    const {market, records} = req.body || {};
    if(!Array.isArray(records) || !records.length) return res.status(400).json({error:"No records supplied"});
    const compact = records.slice(-3000).map(r=>({
      date:r.date, market:r.market, open_ank:r.open, open_patti:r.openPatti,
      close_ank:r.close, close_patti:r.closePatti, jodi:r.jodi
    }));
    const response = await client.responses.create({
      model: "gpt-5.6-luna",
      store: false,
      instructions:
        "You are a historical market-data analyst. Analyze only the supplied historical data. "+
        "Return a concise Hindi report with: data quality, frequency observations, repeated values, "+
        "gaps/changes, market-wise trends, and limitations. Do not predict future outcomes, do not "+
        "recommend any betting number/jodi/patti, and do not claim that historical frequency makes a future result more likely.",
      input: `Market: ${market}\nHistorical records JSON:\n${JSON.stringify(compact)}`
    });
    res.json({analysis:response.output_text || "No analysis returned."});
  } catch(e) {
    console.error(e);
    res.status(500).json({error:e?.message || "AI service error"});
  }
});

const port=process.env.PORT || 3000;
app.listen(port,()=>console.log(`Mahakal running at http://localhost:${port}`));
